// Import what we need
const ui = Vars.ui;
const settings = Core.settings;

// Store unit names and colors in Maps
var unitNames = new java.util.HashMap();
var unitColors = new java.util.HashMap();

// Store the last tapped unit
var lastTapped = null;
var canShowDialog = true;

// Settings
var renamerEnabled = true;
var nameSize = 0.3; // Default size

// Load saved data when game starts
function loadData() {
  try {
    var savedNames = settings.getString("unit-namer-names", "{}");
    var savedColors = settings.getString("unit-namer-colors", "{}");
    var parsedNames = JSON.parse(savedNames);
    var parsedColors = JSON.parse(savedColors);
    
    // Load names
    for (var key in parsedNames) {
      unitNames.put(parseInt(key), parsedNames[key]);
    }
    
    // Load colors
    for (var key in parsedColors) {
      unitColors.put(parseInt(key), parsedColors[key]);
    }
    
    // Load settings
    renamerEnabled = settings.getBool("unitnamerenabled", true);
    nameSize = settings.getInt("unitnamersize", 30) / 100.0;
  } catch (e) {
    print("Unit Namer: Error loading data - " + e);
  }
}

// Save data
function saveData() {
  try {
    var namesObj = {};
    var colorsObj = {};
    
    var it = unitNames.entrySet().iterator();
    while (it.hasNext()) {
      var entry = it.next();
      namesObj[entry.getKey()] = entry.getValue();
    }
    
    var it2 = unitColors.entrySet().iterator();
    while (it2.hasNext()) {
      var entry = it2.next();
      colorsObj[entry.getKey()] = entry.getValue();
    }
    
    settings.put("unit-namer-names", JSON.stringify(namesObj));
    settings.put("unit-namer-colors", JSON.stringify(colorsObj));
  } catch (e) {
    print("Unit Namer: Error saving data - " + e);
  }
}

// This runs when the game loads
Events.on(ClientLoadEvent, () => {
  loadData();
  
  ui.showInfoToast("[sky]✨ Unit Namer loaded! Check settings to customize!", 3);
  
  // Add settings menu with icon
  ui.settings.addCategory("Unit Namer", Icon.edit, table => {
    // Toggle on/off
    table.checkPref("Enable Unit Renamer", true, val => {
      renamerEnabled = val;
      ui.showInfoToast(val ? "[lime]✅ Unit Renamer Enabled!" : "[scarlet]❌ Unit Renamer Disabled!", 2);
    });
    
    table.row();
    
    // Name size slider - sliderPref saves automatically
    table.sliderPref("Name Size", 30, 10, 50, 5, val => {
      nameSize = val / 100.0;
    });
    
    table.row();
    
    // Static text showing range - NEVER UPDATES
    table.add("[gray]Range: 10 - 50").left().padTop(5);
    
    table.row();
    
    // Clear all names button
    table.button("Clear All Names", () => {
      ui.showConfirm("Are you sure?", "This will remove all unit names!", () => {
        unitNames.clear();
        unitColors.clear();
        saveData();
        ui.showInfoToast("[scarlet]🗑️ All names cleared!", 2);
      });
    }).size(200, 50).padTop(20);
  });
  
  // Check every frame for tapped units
  Events.run(Trigger.update, () => {
    if (!renamerEnabled) return; // Skip if disabled
    
    var input = Vars.control.input;
    
    // Check if a unit was tapped AND we can show dialog
    if (input.unitTapped != null && canShowDialog) {
      lastTapped = input.unitTapped;
      canShowDialog = false;
      showRenameDialog(lastTapped);
      
      // Clear the tapped unit immediately
      input.unitTapped = null;
      
      // Allow dialog again after 1 second
      Timer.schedule(() => {
        canShowDialog = true;
      }, 1);
    }
  });
});

// Draw custom names above units
Events.on(EventType.WorldLoadEvent, () => {
  Timer.schedule(() => {
    Events.run(Trigger.draw, () => {
      // Sync nameSize with settings
      var currentSize = settings.getInt("Name Size", 30);
      nameSize = currentSize / 100.0;
      
      // Sync enabled state
      renamerEnabled = settings.getBool("Enable Unit Renamer", true);
      
      Groups.unit.each(unit => {
        if (unitNames.containsKey(unit.id)) {
          var name = unitNames.get(unit.id);
          var colorName = unitColors.get(unit.id);
          if (!colorName) colorName = "white";
          
          var font = Fonts.outline;
          var color = getColorFromName(colorName);
          
          Draw.z(Layer.overlayUI);
          
          // Set the font color properly
          font.setColor(color);
          
          font.getData().setScale(nameSize);
          font.draw(name, unit.x, unit.y + 15, Align.center);
          font.getData().setScale(1);
          
          // Reset font color
          font.setColor(Color.white);
        }
      });
    });
  }, 0.1);
});

// Convert color name to Color object
function getColorFromName(colorName) {
  var colors = {
    "white": Color.white,
    "red": Color.red,
    "blue": Color.blue,
    "green": Color.green,
    "yellow": Color.yellow,
    "orange": Color.orange,
    "purple": Color.purple,
    "cyan": Color.cyan,
    "pink": Color.pink,
    "lime": Color.lime,
    "gold": Color.gold,
    "sky": Color.sky
  };
  return colors[colorName] || Color.white;
}

// Function to show the rename dialog
function showRenameDialog(unit) {
  var dialog = new BaseDialog("[sky]🏷️ Unit Options");
  
  dialog.cont.button("[gold]✏️ Rename Unit", () => {
    dialog.hide();
    askForName(unit);
  }).size(200, 50);
  
  dialog.cont.row();
  
  dialog.cont.button("[cyan]🎨 Change Color", () => {
    dialog.hide();
    showColorPicker(unit);
  }).size(200, 50);
  
  dialog.cont.row();
  
  // Only show clear name if unit has a name
  if (unitNames.containsKey(unit.id)) {
    dialog.cont.button("[scarlet]❌ Clear Name", () => {
      unitNames.remove(unit.id);
      unitColors.remove(unit.id);
      saveData();
      ui.showInfoToast("[scarlet]Name cleared!", 2);
      dialog.hide();
    }).size(200, 50);
    
    dialog.cont.row();
  }
  
  dialog.cont.button("[lightgray]Close", () => {
    dialog.hide();
  }).size(200, 50);
  
  dialog.show();
}

// Function to ask for the new name
function askForName(unit) {
  ui.showTextInput("✏️ Rename Unit", "Enter new name", 15, "", text => {
    if (text != "") {
      unitNames.put(unit.id, text);
      // Set default color if not set
      if (!unitColors.containsKey(unit.id)) {
        unitColors.put(unit.id, "white");
      }
      saveData();
      ui.showInfoToast("[sky]✨ Unit renamed to: [accent]" + text + "!", 3);
    }
  });
}

// Function to show color picker
function showColorPicker(unit) {
  var dialog = new BaseDialog("[sky]🎨 Choose Name Color");
  
  var colors = [
    ["white", "White"],
    ["red", "Red"],
    ["blue", "Blue"],
    ["green", "Green"],
    ["yellow", "Yellow"],
    ["orange", "Orange"],
    ["purple", "Purple"],
    ["cyan", "Cyan"],
    ["pink", "Pink"],
    ["lime", "Lime"],
    ["gold", "Gold"],
    ["sky", "Sky Blue"]
  ];
  
  for (var i = 0; i < colors.length; i++) {
    var colorData = colors[i];
    var colorName = colorData[0];
    var displayName = colorData[1];
    
    (function(cName, dName) {
      dialog.cont.button("[" + cName + "]" + dName, () => {
        unitColors.put(unit.id, cName);
        saveData();
        ui.showInfoToast("[" + cName + "]Color changed to " + dName + "!", 2);
        dialog.hide();
      }).size(200, 50);
    })(colorName, displayName);
    
    if ((i + 1) % 2 == 0) {
      dialog.cont.row();
    }
  }
  
  dialog.cont.row();
  
  dialog.cont.button("[lightgray]Cancel", () => {
    dialog.hide();
  }).size(200, 50);
  
  dialog.show();
}

// Save data periodically
Events.on(EventType.ClientLoadEvent, () => {
  Timer.schedule(() => {
    saveData();
  }, 5, 5); // Auto-save every 5 seconds
});